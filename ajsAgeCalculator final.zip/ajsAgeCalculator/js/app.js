//app.js

var myApp = angular.module('ajsAgeCalculator', ['ngResource']);

myApp.controller('ajsacController', ['$scope', function($scope){
	
		$scope.uname = "suchitra";
		//$scope.dob= new Date(1992,1,1);
		$scope.dob= "04/03/1992";
		$scope.calculateAge = function calculateAge(dob){
			$scope.ageCl = null;
			var birthdate = new Date(dob);
			var ageDif = Date.now() - birthdate.getTime();
			 var ageDate = new Date(ageDif); // miliseconds from epoch
			$scope.ageCl = Math.abs(ageDate.getUTCFullYear() - 1970);
			//milestones
			$scope.milestones =  [
								{
								  "id": 0,
								  "age": 11,
								  "miles" : "Learn new good habits",
								  "icon": "img/nature.png"
								},
								{
								  "id": 1,
								  "age": 15,
								  "miles" : "Its time for first crush",
								  "icon": "img/shapes.png"
								},
								{
								  "id": 2,
								  "age": 19,
								  "miles" : "Its time to look for Full time Job",
								  "icon": "img/business.png"
								},
								{
								  "id": 3,
								  "age": 20,
								  "miles" : "Pass your driving test",
								  "icon": "img/technology.png"
								},
								{
								  "id": 4,
								  "age": 21,
								  "miles" : "Plan for first Holiday with friends",
								  "icon": "img/holidays.png"
								},
								{
								  "id": 5,
								  "age": 22,
								  "miles" : "Its time to move out and explore",
								  "icon": "img/explore.png"
								},
								{
								  "id": 6,
								  "age": 23,
								  "miles" : "Be a Bridesmaid or Best Man",
								  "icon": "img/fashion.png"
								},
								{
								  "id": 7,
								  "age": 24,
								  "miles" : "Its time to rent on your own",
								  "icon": "img/landscape.png"
								},
								{
								  "id": 8,
								  "age": 25,
								  "miles" : "Get Engaged now",
								  "icon": "img/Wedding-Ring.png"
								},
								{
								  "id": 9,
								  "age": 27,
								  "miles" : "Get Married now",
								  "icon": "img/people.png"
								},
								{
								  "id": 10,
								  "age": 28,
								  "miles" : "Its time to have First Child",
								  "icon": "img/child.png"
								},
								{
								  "id": 11,
								  "age": 29,
								  "miles" : "Its time to Buy your First House",
								  "icon": "img/home.png"
								},
								{
								  "id": 12,
								  "age": 30,
								  "miles" : "Please do charity and donations",
								  "icon": "img/charity.png"
								},
								{
								  "id": 13,
								  "age": 31,
								  "miles" : "Its time to have a Second Child",
								  "icon": "img/family.png"
								},
								{
								  "id": 14,
								  "age": 32,
								  "miles" : "Its time to buy a Brand new Car",
								  "icon": "img/transport.png"
								},
								{
								  "id": 15,
								  "age": 34,
								  "miles" : "Become a manager at work",
								  "icon": "img/manager.png"
								},
								{
								  "id": 16,
								  "age": 35,
								  "miles" : "Think about starting a business",
								  "icon": "img/social.png"
								},
								{
								  "id": 17,
								  "age": 36,
								  "miles" : "Start enjoying two holidays per year",
								  "icon": "img/holidays_family.png"
								},
								{
								  "id": 18,
								  "age": 37,
								  "miles" : "Start earning 40K a year",
								  "icon": "img/money.png"
								},
								{
								  "id": 19,
								  "age": 39,
								  "miles" : "Look at buying property to let",
								  "icon": "img/office.png"
								},
								{
								  "id": 20,
								  "age": 60,
								  "miles" : "Its time to retire and enjoy life with family",
								  "icon": "img/two.png"
								}
							 ];
			//show milestones
			var myAgehere;
			angular.forEach($scope.milestones, function(myAge){
				if ( myAge.age == $scope.ageCl ){ 
					myAgehere = true;
					$scope.milesAge = myAge.miles;
					$scope.icons = myAge.icon;
				}
			});
			if ( myAgehere != true ) {
					$scope.milesAge = "Live long happily";
			}	
		};
		
}]);