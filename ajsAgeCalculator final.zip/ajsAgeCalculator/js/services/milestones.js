//factory

myApp.factory('milestones', function($resource){
	return $resource('js/services/milestones.json');
});